
package javaapplication14;

import java.util.Scanner;

public class JavaApplication14 {

    public static void main(String[] args) {
      Scanner reader = new Scanner(System.in);
  String word = reader.nextLine();
  System.out.println(isPalindrome(word));
    }
    public static boolean isPalindrome(String word) {
        String wordx="";
 for (int x=word.length()-1; x>=0;  x--){
           wordx=wordx+word.charAt(x);}
 if (word.equalsIgnoreCase(wordx))
 return true;
 else
 return false;
}
}
